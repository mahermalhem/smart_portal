<?php

namespace backend\components;
use Yii;

trait ApiHandler
{
    public function successResponse($data = null, $msg = "successful", $statusCode = 200)
    {
        Yii::$app->response->statusCode = $statusCode;
        return [
            'status' => true,
            'msg' => $msg,
            'data' => $data
        ];
    }

    public function successResponseWithoutMsg() {
       Yii::$app->response->statusCode = 200; // Must be only 204 and without status = true
        return [
            'status' => true,
        ];
    }

    public function errorValidationResponse($errors = null, $msg = "validation-error, something wrong!", $statusCode = 403)
    {
        Yii::$app->response->statusCode = $statusCode;
        return [
            'status' => false,
            'msg' => $msg,
            'errors' => $errors
        ];
    }

    public function errorNotFoundResponse($msg = 'Page Not Found', $statusCode = 404)
    {
        Yii::$app->response->statusCode = $statusCode;
        return [
            'status' => false,
            'msg' => $msg
        ];
    }

    public function errorMsgResponse($errors = null, $msg = "error, something wrong!", $statusCode = 400)
    {
        Yii::$app->response->statusCode = $statusCode;
        return [
            'status' => false,
            'msg' => $msg
        ];
    }
}