<?php

namespace backend\components;

use Yii;

trait EmailSender
{
    public function generateVerificationCode()
    {
        return mt_rand(100000, 999999);
    }

    public function sendEmailVerification($email, $username)
    {

        $verification_number = $this->generateVerificationCode();
        Yii::$app
            ->mailer
            ->compose()
            ->setFrom([Yii::$app->params['supportEmail'] => "Smart Portal"])
            ->setTo($email)
            ->setSubject('Account verification')
            ->setTextBody("Hello $username,
Take the number below to verify your email:
" . $verification_number)
            ->send();

        return (string) $verification_number;
    }

    public function sendEmailResetPasswordVerification($email, $username)
    {

        $verification_number = $this->generateVerificationCode();
        Yii::$app
            ->mailer
            ->compose()
            ->setFrom([Yii::$app->params['supportEmail'] => "Smart Portal"])
            ->setTo($email)
            ->setSubject('Password reset verification')
            ->setTextBody("Hello $username,
Take the number below to reset your password:
" . $verification_number)
            ->send();

        return (string) $verification_number;
    }
}