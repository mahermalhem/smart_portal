<?php

namespace backend\controllers;

use Yii;
use backend\models\UserLogin;
use backend\models\UserResource;
use backend\components\EmailSender;

/**
 * AuthenticationController controller
 */
class AuthenticationController extends RestBaseController
{
    use EmailSender;

    /**
     * @return array|UserResource|null
     */
    public function actionLogin()
    {

        try {
            $model = new UserLogin();
            if (!$model->load($this->requestParams, '')) {
                return $this->errorMsgResponse();
            }
            if (!$user = $model->login()) {
                return $this->errorValidationResponse($model->errors);
            }

            return $this->successResponse($user);
        } catch (\Exception $exception) {
            return $this->errorMsgResponse(null, $exception->getMessage());
        }
    }

    public function actionRegister()
    {
        try {
            $model = new UserResource(['scenario' => UserResource::SCENARIO_REGISTER]);
            if (!$model->load($this->requestParams, '')) {
                return $this->errorMsgResponse();
            }

            $model->setPassword($model->password);
            $model->type = $model->type ?? UserResource::TYPE_JOB_SEEKER;

            if(!$model->validate()) {
                return $this->errorValidationResponse($model->errors);
            }

            $model->verification_token = $this->sendEmailVerification($model->email,$model->username);

            if(!$model->device_token && !Yii::$app->request->headers->has('device-token')) {
                $model->addError("device_token", 'messing device token');
                return false;
            }

            $model->device_token = Yii::$app->request->headers->get('device-token');
            if (!$model->save()) {
                return $this->errorValidationResponse($model->errors);
            }
            $model->refresh();
            return $this->successResponse($model);

        } catch (\Exception $exception) {
            return $this->errorMsgResponse($exception->getMessage());
        }
    }

    public function actionProfile()
    {
        try {
            return $this->successResponse(\Yii::$app->user->identity);

        } catch (\Exception $exception) {
            return $this->errorMsgResponse($exception->getMessage());
        }
    }

    public function actionUpdateProfile()
    {
        try {
            $model = UserResource::findOne(\Yii::$app->user->getId());
            if (!$model->load($this->requestParams, '')) {
                return $this->errorMsgResponse();
            }

            if(!$model->save()) {
                return $this->errorValidationResponse($model->errors);
            }

            return $this->successResponse($model);

        } catch (\Exception $exception) {
            return $this->errorMsgResponse($exception->getMessage());
        }
    }

    public function actionLogout()
    {
        try {
            $model = UserResource::findOne(\Yii::$app->user->getId());
            $model->auth_key = null;
            if(!$model->save()) {
                return $this->errorValidationResponse($model->errors);
            }
            $this->successResponseWithoutMsg();

        } catch (\Exception $exception) {
            return $this->errorMsgResponse($exception->getMessage());
        }
    }

    public function actionSendResetPasswordVerification()
    {
        try {
            if (!isset($this->requestParams['email']) || !$this->requestParams['email']) {
                return $this->errorValidationResponse(['email' => ['Email cannot be blank!']]);
            }

            $email = $this->requestParams['email'];
            $model = UserResource::findOne(['email' => $email, 'status' => UserResource::STATUS_ACTIVE]);
            if (!$model) {
                return $this->errorNotFoundResponse('Error, user not found!');
            }

            $model->verification_token = $this->sendEmailResetPasswordVerification($model->email, $model->username);

            if (!$model->save()) {
                return $this->errorValidationResponse($model->errors);
            }

            return $this->successResponse(['verification_code' => $model->verification_token]);

        } catch (\Exception $exception) {
            return $this->errorMsgResponse($exception->getMessage());
        }
    }

    public function actionResetPassword()
    {
        try {
            if (!isset($this->requestParams['email']) || !$this->requestParams['email']) {
                return $this->errorValidationResponse(['email' => ['Email cannot be blank!']]);
            }

            if (!isset($this->requestParams['code']) || !$this->requestParams['code']) {
                return $this->errorValidationResponse(['code' => ['Code cannot be blank!']]);
            }

            $email = $this->requestParams['email'];
            $code = $this->requestParams['code'];

            $model = UserResource::findOne(['email' => $email, 'status' => UserResource::STATUS_ACTIVE]);
            if (!$model) {
                return $this->errorNotFoundResponse('Error, user not found!');
            }

            $model->scenario = UserResource::SCENARIO_RESET;

            if (!$model->load($this->requestParams, '')) {
                return $this->errorMsgResponse();
            }

            if($model->verification_token != $code) {
                return $this->errorValidationResponse(['code' => ['Invalid code!']]);
            }

            $model->setPassword($model->password);
            $model->verification_token = null;

            if (!$model->save()) {
                return $this->errorValidationResponse($model->errors);
            }

            $this->successResponseWithoutMsg();

        } catch (\Exception $exception) {
            return $this->errorMsgResponse($exception->getMessage());
        }
    }

    public function actionActivateUser()
    {
        if (!isset($this->requestParams['email']) || !$this->requestParams['email']) {
            return $this->errorValidationResponse(['email' => ['Email cannot be blank!']]);
        }

        if (!isset($this->requestParams['code']) || !$this->requestParams['code']) {
            return $this->errorValidationResponse(['code' => ['Code cannot be blank!']]);
        }

        $email = $this->requestParams['email'];
        $code = $this->requestParams['code'];

        $model = UserResource::findOne(['email' => $email, 'status' => UserResource::STATUS_INACTIVE]);
        if (!$model) {
            return $this->errorNotFoundResponse('Error, user not found!');
        }

        $model->status = UserResource::STATUS_ACTIVE;
        if (!$model->validate()) {
            return $this->errorValidationResponse($model->errors);
        }

        if($model->verification_token != $code) {
            return $this->errorValidationResponse(['code' => ['Invalid code!']]);
        }

        $model->generateAuthKey();
        $model->verification_token = null;

        if (!$model->save()) {
            return $this->errorValidationResponse($model->errors);
        }
        return $this->successResponse($model);
    }

}
