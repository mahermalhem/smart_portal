<?php

namespace backend\controllers;

use Yii;
use yii\filters\AccessControl;

use common\models\JobSearch;
use backend\models\JobResource;
use backend\models\UserResource;
use backend\models\JobSearchResource;

/**
 * Job controller
 */
class JobController extends RestBaseController
{

    public function behaviors()
    {
        return array_merge(parent::behaviors(), [
            'access' => [
                'class' => AccessControl::class,
                'only' => ['create-job', 'update-job', 'delete-job'],
                'rules' => [
                    [
                        'actions' => ['create-job', 'update-job', 'delete-job'],
                        'allow' => true,
                        'matchCallback' => function ($rule, $action) {
                            return !Yii::$app->user->isGuest && Yii::$app->user->identity->type == UserResource::TYPE_EMPLOYEE;
                        }
                    ],
                ],
            ],
        ]);
    }

    public function actionJobSearch()
    {
        $searchModel = new JobSearchResource();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        if (isset($this->requestParams['query']) && $this->requestParams['query']) {
            $dataProvider->query->andWhere(['or',
                ['like', 'title', '%' . $this->requestParams['query'] . '%', false],
                ['like', 'description', '%' . $this->requestParams['query'] . '%', false],
                ['like', 'country', '%' . $this->requestParams['query'] . '%', false],
                ['like', 'address', '%' . $this->requestParams['query'] . '%', false],
            ]);
        }
        $page_count = ceil($dataProvider->totalCount / $dataProvider->pagination->pageSize);
        return $this->successResponse(['currentPage' => $dataProvider->pagination->page, 'pageCount' => $page_count, 'list' => $dataProvider]);
    }

    public function actionCreateJob()
    {
        try {
            $model = new JobResource();
            $model->company_id = Yii::$app->user->getId();
            if (!$model->load($this->requestParams, '')) {
                return $this->errorMsgResponse();
            }
            $model->company_id = Yii::$app->user->getId();
            if (!$model->save()) {
                return $this->errorValidationResponse($model->errors);
            }

            return $this->successResponse($model);

        } catch (\Exception $exception) {
            return $this->errorMsgResponse($exception->getMessage());
        }
    }

    public function actionUpdateJob($id)
    {
        try {
            $model = JobResource::findOne($id);
            if (!$model) {
                return $this->errorNotFoundResponse('Job Not Found!');
            }

            if (!$model->load($this->requestParams, '')) {
                return $this->errorMsgResponse();
            }

            if (!$model->save()) {
                return $this->errorValidationResponse($model->errors);
            }

            return $this->successResponse($model);

        } catch (\Exception $exception) {
            return $this->errorMsgResponse($exception->getMessage());
        }
    }

    public function actionDeleteJob($id)
    {
        $model = JobResource::findOne($id);
        if (!$model) {
            return $this->errorNotFoundResponse('Job Not Found!');
        }

        if (!$model->delete()) {
            return $this->errorMsgResponse();
        }

        $this->successResponseWithoutMsg();
    }

    public function actionViewJob($id)
    {
        $model = JobResource::findOne($id);
        if (!$model) {
            return $this->errorNotFoundResponse('Job Not Found!');
        }

        return $this->successResponse($model);
    }

    public function actionJobList()
    {
        $searchModel = new JobSearchResource();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $page_count = ceil($dataProvider->totalCount / $dataProvider->pagination->pageSize);
        return $this->successResponse(['currentPage' => $dataProvider->pagination->page, 'pageCount' => $page_count, 'list' => $dataProvider]);
    }
}
