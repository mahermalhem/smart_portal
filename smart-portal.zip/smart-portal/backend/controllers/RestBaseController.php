<?php

namespace backend\controllers;

use Yii;
use yii\rest\Controller;
use yii\filters\auth\CompositeAuth;
use yii\filters\auth\HttpBasicAuth;
use yii\filters\auth\HttpBearerAuth;
use backend\components\ApiHandler;

/**
 * Class RestBaseController
 * @package backend\controllers
 */
class RestBaseController extends Controller
{
    use ApiHandler;

    public $enableCsrfValidation = false;
    public $requestParams;

    public function init()
    {
        parent::init();
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $this->requestParams = array_merge(Yii::$app->request->post(), Yii::$app->request->get());
    }

    public function behaviors()
    {
        $behaviors = parent::behaviors();

        $behaviors['authenticator'] = [
            'class' => CompositeAuth::class,
            'authMethods' => [
                HttpBasicAuth::class,
                HttpBearerAuth::class,
            ],
            'except' => [
                'index', // SiteController
                'login', // AuthenticationController
                'register', // AuthenticationController
                'send-reset-password-verification', // AuthenticationController
                'reset-password', // AuthenticationController
                'activate-user' // AuthenticationController
            ],
            'optional' => [
                'log-user-device' // SiteController
            ],
        ];

        return $behaviors;
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
        ];
    }

}