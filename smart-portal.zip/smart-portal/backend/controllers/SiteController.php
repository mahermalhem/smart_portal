<?php

namespace backend\controllers;

use Yii;
use backend\models\UserResource;

/**
 * Site controller
 */
class SiteController extends RestBaseController
{
    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        return "Welcome API";
    }

    public function actionLogUserDevice()
    {
        if(!Yii::$app->user->isGuest) {
            $model = UserResource::findOne(Yii::$app->user->getId());
            $model->device_token = Yii::$app->request->headers['device-id'];
            if (!$model->save()) {
                return $this->errorValidationResponse($model->errors);
            }
        }
        $this->successResponseWithoutMsg();
    }
}
