<?php

namespace backend\controllers;

use common\models\Job;
use Yii;
use yii\filters\AccessControl;
use backend\models\UserResource;
use backend\models\UserAppliedResource;
use backend\models\UserAppliedSearchResource;

/**
 * UserJob controller
 */
class UserJobController extends RestBaseController
{

    public function behaviors()
    {
        return array_merge(parent::behaviors(), [
               'access' => [
                   'class' => AccessControl::class,
                   'only' => ['apply-job', 'update-apply-job', 'cancel-apply-job', 'view-apply-job', 'user-applications-list', 'company-users-applications-list', 'update-apply-job-status'],
                   'rules' => [
                       [
                           'actions' => ['apply-job', 'update-apply-job', 'cancel-apply-job', 'view-apply-job', 'user-applications-list'],
                           'allow' => true,
                           'matchCallback' => function ($rule, $action) {
                               return !Yii::$app->user->isGuest && Yii::$app->user->identity->type == UserResource::TYPE_JOB_SEEKER;
                           }
                       ],
                       [
                           'actions' => ['update-apply-job-status', 'company-users-applications-list', 'view-company-application-job'],
                           'allow' => true,
                           'matchCallback' => function ($rule, $action) {
                               return !Yii::$app->user->isGuest && Yii::$app->user->identity->type == UserResource::TYPE_EMPLOYEE;
                           }
                       ],
                   ],
               ],
        ]);
    }

    public function actionApplyJob($id)
    {
        try {
            $model = new UserAppliedResource();

            if(!$model->load($this->requestParams, '')) {
                return $this->errorMsgResponse();
            }

            if(isset($_FILES['file'])) {
                $model->file = $_FILES['file'];
            }

            $model->user_id = Yii::$app->user->getId();
            $model->job_id = $id;

            if(!$model->save()) {
                return $this->errorValidationResponse($model->errors);
            }

            $model->refresh();
            return $this->successResponse($model);

        } catch (\Exception $exception) {
            return $this->errorMsgResponse($exception->getMessage());
        }
    }

    public function actionUpdateApplicationJob($id)
    {
        try {
            $model = UserAppliedResource::findOne($id);

            if(!$model) {
                return $this->errorNotFoundResponse('Not Found!');
            }

            if(!$model->load($this->requestParams, '')) {
                return $this->errorMsgResponse();
            }

            if(!$model->save()) {
                return $this->errorValidationResponse($model->errors);
            }

            $model->refresh();
            return $this->successResponse($model);

        } catch (\Exception $exception) {
            return $this->errorMsgResponse($exception->getMessage());
        }
    }

    public function actionCancelApplicationJob($id)
    {
        try {
            $model = UserAppliedResource::findOne($id);

            if(!$model) {
                return $this->errorNotFoundResponse('Not Found!');
            }

            if(!$model->delete()) {
                return $this->errorMsgResponse();
            }

            return $this->successResponseWithoutMsg();

        } catch (\Exception $exception) {
            return $this->errorMsgResponse($exception->getMessage());
        }
    }

    public function actionViewApplicationJob($id)
    {
        try {
            $model = UserAppliedResource::find()->where(['id' => $id, 'user_id' => Yii::$app->user->getId()])->one();

            if(!$model) {
                return $this->errorNotFoundResponse('Not Found!');
            }

            return $this->successResponse($model);

        } catch (\Exception $exception) {
            return $this->errorMsgResponse($exception->getMessage());
        }
    }

    public function actionViewCompanyApplicationJob($id)
    {
        try {
            $model = UserAppliedResource::find()
                ->innerJoinWith(['job'])
                ->where([
                    UserAppliedSearchResource::tableName() . '.id' => $id,
                    Job::tableName() . '.company_id' => Yii::$app->user->getId()
                ])->one();

            if(!$model) {
                return $this->errorNotFoundResponse('Not Found!');
            }

            return $this->successResponse($model);

        } catch (\Exception $exception) {
            return $this->errorMsgResponse($exception->getMessage());
        }
    }

    public function actionUserApplicationsList()
    {
        $searchModel = new UserAppliedSearchResource();
        $searchModel->user_id = Yii::$app->user->getId();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $page_count = ceil($dataProvider->totalCount / $dataProvider->pagination->pageSize);
        return $this->successResponse(['currentPage' => $dataProvider->pagination->page, 'pageCount' => $page_count, 'list' => $dataProvider]);
    }

    public function actionUpdateApplicationJobStatus($id)
    {
        $model = UserAppliedResource::findOne($id);
        $model->load($this->requestParams, '');
        if(!in_array($model->status, UserAppliedResource::EmployeeStatusList)) {
            return $this->errorNotFoundResponse(Yii::t('app', 'error, invalid status!'));
        }

        if(!$model->save()) {
            return $this->errorValidationResponse($model->errors);
        }

        return $this->successResponse($model);
    }

    public function actionCompanyUsersApplicationsList()
    {
        $searchModel = new UserAppliedSearchResource();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $dataProvider->query->andWhere(['job.company_id' => Yii::$app->user->getId()]);
        $page_count = ceil($dataProvider->totalCount / $dataProvider->pagination->pageSize);
        return $this->successResponse(['currentPage' => $dataProvider->pagination->page, 'pageCount' => $page_count, 'list' => $dataProvider]);
    }
}
