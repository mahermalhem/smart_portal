<?php

namespace backend\models;

use Yii;
use common\models\Job;

/**
 * This is the model class for table "JobResource".
 * @inheritDoc
 */
class JobResource extends Job
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return array_merge(parent::rules(), []);
    }

    public function fields()
    {
        $fields = parent::fields();
        unset($fields['updated_at']);
        return array_merge($fields, [
            'companyDetails' => function ($model) {
                return $model->company;
            }
        ]);
    }

    /**
     * Gets query for [[Company]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCompany()
    {
        return $this->hasOne(UserDetailsResource::className(), ['id' => 'company_id']);
    }
}
