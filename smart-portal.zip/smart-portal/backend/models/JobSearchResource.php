<?php

namespace backend\models;

use common\models\JobSearch;

/**
 * JobSearchResource represents the model behind the search form of `common\models\Job`.
 */
class JobSearchResource extends JobSearch
{
   public function fields()
   {
       $fields = parent::fields();
       unset($fields['updated_at']);
       return array_merge($fields, [
           'companyDetails' => function ($model) {
               return $model->company;
           }
       ]);
   }
}
