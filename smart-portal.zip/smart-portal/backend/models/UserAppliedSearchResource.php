<?php

namespace backend\models;

use Yii;
use yii\helpers\Url;
use common\models\UserAppliedSearch;

/**
 * This is the model class for table "user_applied".
 * @inheritDoc
 */
class UserAppliedSearchResource extends UserAppliedSearch
{
    public function fields()
    {
        return [
            'id',
            'user_id',
            'job_id',
            'status',
            'file' => function ($model) {
                /** @var $model self */
                return Url::to(['/uploads/files/' . $model->file], true);
            },
            'note',
            'created_at',
            'userDetails' => function ($model) {
                return $model->user;
            },
            'jobDetails' => function ($model) {
                return $model->job;
            },
            'companyDetails' => function ($model) {
                return $model->job->company;
            }
        ];
    }

    /**
     * Gets query for [[User]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(UserDetailsResource::className(), ['id' => 'user_id']);
    }

    /**
     * Gets query for [[Job]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getJob()
    {
        return $this->hasOne(JobResource::className(), ['id' => 'job_id']);
    }
}
