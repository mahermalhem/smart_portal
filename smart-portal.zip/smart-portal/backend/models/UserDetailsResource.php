<?php

namespace backend\models;

use Yii;

/**
 * UserDetailsResource model
 */
class UserDetailsResource extends UserResource
{
    public function fields()
    {
        return [
            'id',
            'type',
            'username',
            'email',
            'phone',
        ];
    }
}
