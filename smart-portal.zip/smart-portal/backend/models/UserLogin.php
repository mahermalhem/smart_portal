<?php

namespace backend\models;

use Yii;
use common\models\User;
use backend\components\EmailSender;

/**
 * UserLogin model
 */
class UserLogin extends UserResource
{
    use EmailSender;

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['email', 'password'], 'required'],
            [['username', 'phone', 'password_hash', 'auth_key', 'type', 'status'], 'safe'],
            ['password', 'validateAuthPassword'],
        ];
    }

    /**
     * Validates the password.
     * This method serves as the inline validation for password.
     *
     * @param string $attribute the attribute currently being validated
     * @param array $params the additional name-value pairs given in the rule
     */
    public function validateAuthPassword($attribute, $params)
    {
        if (!$this->hasErrors()) {
            $user = $this->getUser();

            if($user->status == User::STATUS_INACTIVE) {
                $user->verification_token = $this->sendEmailVerification($user->email,$user->username);
                $user->save(false);
                $this->addError('status', 'Inactive user');
                return false;
            }

            if (!$user || !$user->validatePassword($this->password)) {
                $this->addError($attribute, 'Incorrect username or password.');
                return false;
            }

            if(!$user->device_token && !Yii::$app->request->headers->has('device-token')) {
                $this->addError("device_token", 'messing device token');
                return false;
            }
        }
    }

    public function login()
    {
        $this->load(Yii::$app->request->post(), '');
        if (!$this->validate()) {
            return null;
        }

        $this->_user->generateAuthKey();
        $this->_user->password = $this->password;
        $this->_user->device_token = Yii::$app->request->headers->get('device-token');
        $this->_user->save();
        return $this->_user;
    }

    public function beforeSave($insert)
    {
        return parent::beforeSave($insert);
    }
}
