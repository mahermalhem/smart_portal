<?php

namespace backend\models;

use Yii;
use common\models\User;

/**
 * User model
 *
 * @property integer $id
 * @property string $username
 * @property string $password_hash
 * @property string $password_reset_token
 * @property string $verification_token
 * @property string $email
 * @property string $auth_key
 * @property integer $status
 * @property integer $created_at
 * @property integer $updated_at
 * @property string $password write-only password
 */
class UserResource extends User
{
    public $password_confirm;

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return array_merge(parent::rules(), [
            ['password_confirm', 'required', 'on' => [self::SCENARIO_REGISTER, self::SCENARIO_RESET]],
            ['password_confirm', 'compare', 'compareAttribute' => 'password', 'on' => [self::SCENARIO_REGISTER, self::SCENARIO_RESET]]
        ]);
    }

    public function fields()
    {
        return [
            'id',
            'type',
            'status',
            'username',
            'email',
            'phone',
            'verification_code' => function ($model) {
                /** @var $model self */
                return $model->scenario == self::SCENARIO_REGISTER ? $model->verification_token : '';
            },
            'device_token',
            'access_token' => function ($model) {
                return $model->auth_key;
            }
        ];
    }

    public function getUser()
    {
        if ($this->_user === null) {
            $this->_user = self::findByUserEmailAndType($this->email, $this->type);
        }
        return $this->_user;
    }

}
