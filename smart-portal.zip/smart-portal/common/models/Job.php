<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "job".
 *
 * @property int $id
 * @property string|null $title
 * @property string|null $description
 * @property string $country
 * @property string $address
 * @property string $created_at
 * @property string $updated_at
 */
class Job extends base\Job
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return array_merge(parent::rules(), [
            [['title', 'description', 'company_id'], 'required'],
        ]);
    }
}
