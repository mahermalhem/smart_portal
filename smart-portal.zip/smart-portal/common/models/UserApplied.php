<?php

namespace common\models;

use Yii;
use yii\db\ActiveQuery;
use yii\web\UploadedFile;

/**
 * This is the model class for table "user_applied".
 *
 * @property int $id
 * @property int|null $user_id
 * @property string|null $status
 * @property string|null $file
 * @property string|null $note
 * @property string $created_at
 * @property string $updated_at
 *
 * @property User $user
 */
class UserApplied extends base\UserApplied
{
    const STATUS_ACCEPTED = 'accepted';
    const STATUS_REJECTED = 'rejected';
    const STATUS_PENDING = 'pending';

    const EmployeeStatusList = [
        self::STATUS_ACCEPTED,
        self::STATUS_REJECTED
    ];

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return array_merge(parent::rules(), []);
    }

    /**
     * Gets query for [[Job]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getJob()
    {
        return $this->hasOne(Job::className(), ['id' => 'job_id']);
    }

    /**
     * Gets query for [[User]].
     *
     * @return ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

   public function beforeValidate()
   {
       $this->upload();
       return parent::beforeValidate();
   }

    public function upload()
    {
        $file = UploadedFile::getInstanceByName('file');
        $this->file = $file ?? $this->file;
        if($this->file && $file) {
            $imagePathName = $this->file->baseName . '_' . time() . '.' . $this->file->extension;
            if(!$this->file->saveAs( 'uploads/files/'  . $imagePathName)) $imagePathName = null;
            $this->file = $imagePathName;
        }
    }
}
