<?php

namespace common\models\base;

use Yii;

/**
 * This is the model class for table "user".
 *
 * @property int $id
 * @property string|null $type
 * @property string|null $status
 * @property string $username
 * @property string $email
 * @property string $phone
 * @property string $password_hash
 * @property string|null $password_reset_token
 * @property string|null $auth_key
 * @property string|null $device_token
 * @property string|null $verification_token
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Job[] $jobs
 * @property UserApplied[] $userApplieds
 */
class User extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'user';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['username', 'email', 'phone', 'password_hash'], 'required'],
            [['created_at', 'updated_at'], 'safe'],
            [['type', 'status'], 'string', 'max' => 100],
            [['username', 'email', 'password_hash', 'password_reset_token', 'auth_key', 'device_token', 'verification_token'], 'string', 'max' => 255],
            [['phone'], 'string', 'max' => 15],
            [['username'], 'unique'],
            [['email'], 'unique'],
            [['phone'], 'unique'],
            [['password_reset_token'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'type' => Yii::t('app', 'Type'),
            'status' => Yii::t('app', 'Status'),
            'username' => Yii::t('app', 'Username'),
            'email' => Yii::t('app', 'Email'),
            'phone' => Yii::t('app', 'Phone'),
            'password_hash' => Yii::t('app', 'Password Hash'),
            'password_reset_token' => Yii::t('app', 'Password Reset Token'),
            'auth_key' => Yii::t('app', 'Auth Key'),
            'device_token' => Yii::t('app', 'Device Token'),
            'verification_token' => Yii::t('app', 'Verification Token'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    /**
     * Gets query for [[Jobs]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getJobs()
    {
        return $this->hasMany(Job::className(), ['id' => 'job_id'])->viaTable('user_applied', ['user_id' => 'id']);
    }

    /**
     * Gets query for [[UserApplieds]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUserApplieds()
    {
        return $this->hasMany(UserApplied::className(), ['user_id' => 'id']);
    }
}
