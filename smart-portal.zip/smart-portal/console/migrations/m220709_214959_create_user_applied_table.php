<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%user_applied}}`.
 */
class m220709_214959_create_user_applied_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%user_applied}}', [
            'id' => $this->primaryKey(),
            'user_id' => $this->integer(),
            'job_id' => $this->integer(),
            'status' => $this->string(30)->defaultValue("pending"),
            'file' => $this->string(500),
            'note' => $this->string(400),
            'created_at' => $this->timestamp()->notNull()->defaultExpression('CURRENT_TIMESTAMP'),
            'updated_at' => $this->timestamp()->notNull()->defaultExpression('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
        ]);

        $this->addForeignKey('fk_user_and_applied_user_id', 'user_applied', 'user_id', 'user', 'id', 'cascade');
        $this->addForeignKey('fk_job_and_applied_user_id', 'user_applied', 'job_id', 'job', 'id', 'cascade');
        $this->createIndex('ndx_user_id_and_job_id', 'user_applied', ['user_id', 'job_id'],true);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%user_applied}}');
    }
}
