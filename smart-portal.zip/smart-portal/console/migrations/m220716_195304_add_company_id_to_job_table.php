<?php

use yii\db\Migration;

/**
 * Class m220716_195304_add_company_id_to_job_table
 */
class m220716_195304_add_company_id_to_job_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->addColumn('job', 'company_id',$this->integer()->after("id"));
        $this->addForeignKey('fk_user_and_job_company_id', 'job', 'company_id', 'user', 'id');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('job', 'company_id');
        $this->dropForeignKey('fk_user_and_job_company_id','job');
    }
}
