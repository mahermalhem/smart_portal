const AllAnimation={
    EMPTY_LIST:require("../productAssets/animations/searchAnimationEmptyRecords.json"),
}

export {AllAnimation};