const IMAGE={
    SPLASH_BACKGROUND:require("../productAssets/bc.png"),
    DOF3ATTY_LOGO:require("../productAssets/Dof3atty-logo/profile.png"),
    DOFFATY_LOGO_1:require("../productAssets/Dof3atty-logo/dufaaty1.png"),
    DOFFATY_LOGO_2:require("../productAssets/Dof3atty-logo/dufaaty2.png"),
    DOFFATY_LOGO_3:require("../productAssets/Dof3atty-logo/dufaaty3.png"),
    DOFFATY_LOGO_3_SMALL:require("../productAssets/Dof3atty-logo/dufaaty3small.png"),
    DOFFATY_LOGO_4:require("../productAssets/Dof3atty-logo/dufaaty4.png"),
    BACKGROUND_1:require("../productAssets/background1.png"),
    BACKGROUND_2:require("../productAssets/background2.png"),
    BACKGROUND_3:require("../productAssets/background3.png"),
    EXPLORE:require("../productAssets/explore.png"),
    THEME:require("../productAssets/theme.png"),
    DUFAATY_ICON:require("../productAssets/doffatyIconcopy.png"),
}

export {IMAGE};