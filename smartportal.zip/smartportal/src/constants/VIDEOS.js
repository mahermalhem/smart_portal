const VIDEOS={
    SIGN_IN_BACKGROUND:require("../assets/videos/singInBackground.mp4"),
}
export {VIDEOS};