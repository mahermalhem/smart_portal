
export const ENDPOINTS = {
  BASE_URL:'http://54.162.241.44/api/',
  LOGIN:'authentication/login/',
  REGISTER:'authentication/register/',
  ACTIVATE_USER:"/authentication/activate-user/",
  SEND_RESET_PASSWORD_VERFICATION:"/authentication/send-reset-password-verification/",
  RESET_PASSWORD:"/authentication/reset-password/",
  
  COMPANY_JOB_LIST:"job/job-list/"
};
