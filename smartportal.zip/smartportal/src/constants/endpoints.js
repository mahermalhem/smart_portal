
export const ENDPOINTS = {
  BASE_URL:'http://54.162.241.44/api/',
  LOGIN:'authentication/login/',
  REGISTER:'authentication/register/'
};
